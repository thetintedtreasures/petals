import { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  size: number;
  shape: 0 | 1 | 2;
  color: string;
  opacity: number;
  vx: number;
  vy: number;
  rotation: number;
  vr: number;
  swayPhase: number;
  swayAmp: number;
  life: number;
  maxLife: number;
}

export default function DriftingCrochetField() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let particles: Particle[] = [];
    let lastTime = 0;
    const maxParticles = 80;

    const colors = [
      'rgba(212, 165, 116,',   // terracotta
      'rgba(139, 157, 119,',   // sage
      'rgba(232, 201, 160,',   // peach
      'rgba(253, 246, 233,',   // cream
      'rgba(232, 180, 184,',   // blush
    ];

    function resize() {
      if (!canvas) return;
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    }

    function createParticle(): Particle {
      const size = 8 + Math.random() * 16;
      const shapeRand = Math.random();
      const shape: 0 | 1 | 2 = shapeRand < 0.4 ? 0 : shapeRand < 0.75 ? 1 : 2;
      const color = colors[Math.floor(Math.random() * colors.length)];
      const opacity = 0.2 + Math.random() * 0.5;
      const life = 300 + Math.random() * 300;

      return {
        x: canvas!.width / 2 + (Math.random() - 0.5) * 200,
        y: canvas!.height + 20,
        size,
        shape,
        color,
        opacity,
        vx: (Math.random() - 0.5) * 0.6,
        vy: -0.3 - Math.random() * 0.5,
        rotation: Math.random() * Math.PI * 2,
        vr: (Math.random() - 0.5) * 0.02,
        swayPhase: Math.random() * Math.PI * 2,
        swayAmp: 0.3 + Math.random() * 0.7,
        life,
        maxLife: life,
      };
    }

    function drawYarnLoop(ctx: CanvasRenderingContext2D, size: number) {
      const r = size * 0.35;
      ctx.beginPath();
      ctx.arc(-r * 0.5, 0, r, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(r * 0.5, 0, r, 0, Math.PI * 2);
      ctx.stroke();
    }

    function drawBlossom(ctx: CanvasRenderingContext2D, size: number) {
      const petalCount = 5;
      const r = size * 0.4;
      for (let i = 0; i < petalCount; i++) {
        const angle = (i / petalCount) * Math.PI * 2;
        ctx.save();
        ctx.rotate(angle);
        ctx.beginPath();
        ctx.ellipse(0, -r * 0.6, r * 0.25, r * 0.5, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
      ctx.beginPath();
      ctx.arc(0, 0, r * 0.15, 0, Math.PI * 2);
      const currentFill = ctx.fillStyle;
      if (typeof currentFill === 'string') {
        ctx.fillStyle = currentFill.replace(/[\d.]+\)$/, '0.6)');
      }
      ctx.fill();
    }

    function drawPetal(ctx: CanvasRenderingContext2D, size: number) {
      ctx.beginPath();
      ctx.moveTo(0, size * 0.5);
      ctx.bezierCurveTo(
        size * 0.3, size * 0.2,
        size * 0.2, -size * 0.4,
        0, -size * 0.5
      );
      ctx.bezierCurveTo(
        -size * 0.2, -size * 0.4,
        -size * 0.3, size * 0.2,
        0, size * 0.5
      );
      ctx.stroke();
    }

    function animate(timestamp: number) {
      if (!canvas || !ctx) return;

      const dt = Math.min((timestamp - lastTime) / 16.67, 3);
      lastTime = timestamp;

      // Clear with solid background
      ctx.fillStyle = '#FDF6E9';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Spawn new particles
      const spawnRate = 1 + Math.floor(Math.random() * 2);
      for (let i = 0; i < spawnRate; i++) {
        if (particles.length < maxParticles) {
          particles.push(createParticle());
        }
      }

      // Update and draw particles
      particles = particles.filter((p) => {
        const sway = Math.sin(timestamp * 0.0008 + p.swayPhase) * p.swayAmp * 0.5;
        p.x += (p.vx + sway) * dt;
        p.y += p.vy * dt;
        p.rotation += p.vr * dt;
        p.life -= dt;

        if (p.life <= 0 || p.y < -50) {
          return false;
        }

        const lifeRatio = p.life / p.maxLife;
        const fadeIn = Math.min(1, (p.maxLife - p.life) / 60);
        const fadeOut = lifeRatio < 0.2 ? lifeRatio / 0.2 : 1;
        const finalOpacity = p.opacity * fadeIn * fadeOut;

        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rotation);
        ctx.globalAlpha = finalOpacity;

        if (p.shape === 0) {
          // Yarn loop - stroke only
          ctx.strokeStyle = p.color + '1)';
          ctx.lineWidth = p.size * 0.12;
          ctx.lineCap = 'round';
          drawYarnLoop(ctx, p.size);
        } else if (p.shape === 1) {
          // Blossom - fill
          ctx.fillStyle = p.color + '0.5)';
          drawBlossom(ctx, p.size);
        } else {
          // Single petal - stroke
          ctx.strokeStyle = p.color + '0.7)';
          ctx.lineWidth = p.size * 0.1;
          ctx.lineCap = 'round';
          drawPetal(ctx, p.size);
        }

        ctx.restore();
        return true;
      });

      animationId = requestAnimationFrame(animate);
    }

    resize();
    animationId = requestAnimationFrame(animate);

    let resizeTimeout: ReturnType<typeof setTimeout>;
    function handleResize() {
      clearTimeout(resizeTimeout);
      resizeTimeout = setTimeout(resize, 200);
    }

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
      clearTimeout(resizeTimeout);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      role="presentation"
      style={{
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        zIndex: 0,
        pointerEvents: 'none',
      }}
    />
  );
}
