import { useEffect, useCallback } from 'react';
import { X, MessageCircle } from 'lucide-react';
import type { Product } from '@/data/products';

interface ProductDetailProps {
  product: Product | null;
  onClose: () => void;
}

export default function ProductDetail({ product, onClose }: ProductDetailProps) {
  const handleEscape = useCallback(
    (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    },
    [onClose]
  );

  useEffect(() => {
    if (product) {
      document.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    }
    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = '';
    };
  }, [product, handleEscape]);

  if (!product) return null;

  const whatsappLink = `https://wa.me/923227861158?text=Hi!%20I'm%20interested%20in%20ordering%20${encodeURIComponent(product.name)}`;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-8"
      style={{
        backgroundColor: 'rgba(60, 54, 51, 0.6)',
        backdropFilter: 'blur(8px)',
        animation: 'fadeIn 0.3s ease-out',
      }}
      onClick={onClose}
    >
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes scaleIn {
          from { opacity: 0; transform: scale(0.95); }
          to { opacity: 1; transform: scale(1); }
        }
      `}</style>

      <div
        className="relative w-full max-w-[800px] max-h-[90vh] overflow-y-auto bg-white rounded-3xl shadow-2xl"
        style={{
          animation: 'scaleIn 0.3s ease-out',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 rounded-full bg-white/80 hover:bg-white transition-colors"
          aria-label="Close"
        >
          <X className="w-6 h-6 text-taupe hover:text-warm-brown transition-colors" />
        </button>

        <div className="flex flex-col md:flex-row">
          {/* Image */}
          <div className="w-full md:w-1/2 md:min-h-[400px]">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-64 md:h-full object-cover rounded-t-3xl md:rounded-l-3xl md:rounded-tr-none"
            />
          </div>

          {/* Details */}
          <div className="w-full md:w-1/2 p-6 md:p-8 flex flex-col">
            <h2 className="font-serif text-3xl md:text-[32px] text-warm-brown font-semibold leading-tight">
              {product.name}
            </h2>
            <p className="font-serif text-2xl md:text-[28px] text-terracotta mt-2">
              PKR {product.price.toLocaleString()}
            </p>

            <p className="font-sans text-base text-taupe mt-4 leading-relaxed">
              {product.fullDescription}
            </p>

            <p className="font-sans text-xs uppercase tracking-[2px] text-sage mt-4 font-medium">
              Handmade with 100% cotton yarn. Each piece is unique.
            </p>

            <div className="mt-auto pt-6">
              <a
                href={whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 w-full py-4 px-6 bg-[#25D366] hover:bg-[#1fae53] text-white font-sans font-semibold text-base rounded-xl transition-colors"
              >
                <MessageCircle className="w-5 h-5" />
                Order on WhatsApp
              </a>

              <p className="text-center font-sans text-sm text-taupe mt-3">
                or{' '}
                <a
                  href="mailto:hello@petals.pk"
                  className="underline hover:text-warm-brown transition-colors"
                >
                  email us at hello@petals.pk
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
