import Navigation from '@/sections/Navigation';
import Hero from '@/sections/Hero';
import Catalogue from '@/sections/Catalogue';
import About from '@/sections/About';
import Footer from '@/sections/Footer';

export default function Home() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <Hero />
      <Catalogue />
      <About />
      <Footer />
    </div>
  );
}
