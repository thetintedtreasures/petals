import { useState, useEffect } from 'react';
import { Menu, X, MessageCircle, Flower2 } from 'lucide-react';

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    function handleScroll() {
      setIsScrolled(window.scrollY > 200);
    }
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-40 h-16 transition-all duration-300 ${
          isScrolled
            ? 'bg-cream/90 backdrop-blur-xl shadow-sm'
            : 'bg-transparent'
        }`}
      >
        <div className="max-w-[1200px] mx-auto h-full px-6 flex items-center justify-between">
          {/* Brand */}
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="font-display text-2xl text-warm-brown tracking-wide hover:opacity-80 transition-opacity"
          >
            Petals
          </button>

          {/* Desktop links */}
          <div className="hidden md:flex items-center gap-6">
            <button
              onClick={() => scrollToSection('catalogue')}
              className="font-sans text-sm text-taupe hover:text-warm-brown transition-colors"
            >
              Catalogue
            </button>
            <a
              href="https://wa.me/923227861158"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-4 py-2 bg-[#25D366] hover:bg-[#1fae53] text-white rounded-lg text-sm font-medium transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              WhatsApp
            </a>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2 text-warm-brown"
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </nav>

      {/* Mobile overlay */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-50 bg-cream flex flex-col items-center justify-center gap-8 md:hidden">
          <button
            onClick={() => setIsMobileMenuOpen(false)}
            className="absolute top-4 right-4 p-2 text-warm-brown"
            aria-label="Close menu"
          >
            <X className="w-6 h-6" />
          </button>

          <Flower2 className="w-12 h-12 text-terracotta mb-4" />

          <button
            onClick={() => scrollToSection('catalogue')}
            className="font-sans text-xl text-warm-brown hover:text-terracotta transition-colors"
          >
            Catalogue
          </button>

          <a
            href="https://wa.me/923227861158"
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => setIsMobileMenuOpen(false)}
            className="flex items-center gap-2 px-6 py-3 bg-[#25D366] text-white rounded-xl text-lg font-medium"
          >
            <MessageCircle className="w-5 h-5" />
            WhatsApp Us
          </a>
        </div>
      )}
    </>
  );
}
