import { MessageCircle, Mail } from 'lucide-react';

export default function Footer() {
  return (
    <footer
      id="contact"
      className="py-12 md:py-16 px-4 md:px-6 border-t border-peach"
      style={{ backgroundColor: '#FDF6E9' }}
    >
      <div className="max-w-[600px] mx-auto text-center">
        <h2 className="font-serif text-2xl md:text-[32px] text-warm-brown">
          Get in Touch
        </h2>

        <a
          href="https://wa.me/923227861158"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-3 mt-6 px-10 py-4 bg-[#25D366] hover:bg-[#1fae53] text-white rounded-xl font-sans font-semibold text-base transition-colors shadow-lg"
        >
          <MessageCircle className="w-5 h-5" />
          Chat on WhatsApp
        </a>

        <p className="font-sans text-base text-taupe mt-4">
          <a
            href="mailto:hello@petals.pk"
            className="inline-flex items-center gap-2 hover:text-warm-brown transition-colors"
          >
            <Mail className="w-4 h-4" />
            hello@petals.pk
          </a>
        </p>

        <p className="font-sans text-sm text-sage mt-6">
          Based in Pakistan | Shipping nationwide
        </p>

        <p className="font-sans text-xs text-taupe mt-8">
          &copy; {new Date().getFullYear()} Petals. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
