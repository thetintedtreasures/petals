import { useState, useRef, useEffect } from 'react';
import { products, comingSoonProducts, categories } from '@/data/products';
import type { Product } from '@/data/products';
import ProductDetail from '@/components/ProductDetail';

export default function Catalogue() {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [visibleProducts, setVisibleProducts] = useState<Set<string>>(new Set());
  const sectionRef = useRef<HTMLDivElement>(null);

  const filteredProducts =
    activeCategory === 'all'
      ? products
      : products.filter((p) => p.category === activeCategory);

  // Intersection observer for scroll animations
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const id = entry.target.getAttribute('data-product-id');
            if (id) {
              setVisibleProducts((prev) => new Set(prev).add(id));
            }
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );

    const cards = sectionRef.current?.querySelectorAll('[data-product-id]');
    cards?.forEach((card) => observer.observe(card));

    return () => observer.disconnect();
  }, [filteredProducts]);

  return (
    <section
      id="catalogue"
      ref={sectionRef}
      className="py-16 md:py-20 px-4 md:px-6"
      style={{ backgroundColor: '#FDF6E9' }}
    >
      <div className="max-w-[1200px] mx-auto">
        {/* Section header */}
        <div className="text-center mb-10">
          <h2 className="font-serif text-3xl md:text-[40px] text-warm-brown">
            Our Collection
          </h2>
          <p className="font-sans text-base text-taupe mt-2">
            Each piece is carefully handcrafted with premium yarn
          </p>
        </div>

        {/* Category tabs */}
        <div className="flex flex-wrap justify-center gap-2 md:gap-3 mb-10">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 md:px-5 py-2 rounded-lg font-sans text-sm transition-all duration-300 ${
                activeCategory === cat.id
                  ? 'bg-terracotta text-white shadow-md'
                  : 'bg-transparent text-taupe border border-peach hover:border-terracotta hover:text-warm-brown'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Product grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map((product) => {
            const isVisible = visibleProducts.has(product.id);
            return (
              <button
                key={product.id}
                data-product-id={product.id}
                onClick={() => setSelectedProduct(product)}
                className={`group text-left bg-white rounded-2xl overflow-hidden shadow-card hover:shadow-card-hover transition-all duration-300 hover:-translate-y-1 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
                }`}
                style={{
                  transition: 'opacity 0.5s ease-out, transform 0.5s ease-out, box-shadow 0.3s ease',
                }}
              >
                <div className="aspect-square overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    loading="lazy"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                </div>
                <div className="p-4 md:p-5">
                  <h3 className="font-sans text-lg font-semibold text-warm-brown">
                    {product.name}
                  </h3>
                  <p className="font-sans text-sm text-taupe mt-1 line-clamp-2">
                    {product.description}
                  </p>
                  <p className="font-serif text-xl text-terracotta mt-2">
                    PKR {product.price.toLocaleString()}
                  </p>
                </div>
              </button>
            );
          })}
        </div>

        {/* Coming Soon */}
        <div className="mt-16 text-center">
          <h3 className="font-serif italic text-2xl text-sage">Coming Soon</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-6 max-w-md mx-auto">
            {comingSoonProducts.map((product) => (
              <div
                key={product.id}
                className="bg-white rounded-2xl overflow-hidden opacity-60"
              >
                <div className="aspect-square overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    loading="lazy"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-3 text-center">
                  <p className="font-sans text-sm font-medium text-warm-brown">
                    {product.name}
                  </p>
                  <p className="font-sans text-xs text-sage mt-1 uppercase tracking-wider">
                    Coming Soon
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Product Detail Modal */}
      <ProductDetail
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
      />
    </section>
  );
}
