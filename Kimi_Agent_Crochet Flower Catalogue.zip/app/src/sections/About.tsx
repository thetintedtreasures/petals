export default function About() {
  return (
    <section
      id="about"
      className="py-16 md:py-20 px-4 md:px-6"
      style={{ backgroundColor: '#3C3633' }}
    >
      <div className="max-w-[800px] mx-auto text-center">
        <h2 className="font-serif text-3xl md:text-4xl text-cream">
          Our Story
        </h2>
        <p className="font-sans text-base md:text-lg leading-relaxed mt-6" style={{ color: 'rgba(253, 246, 233, 0.85)', lineHeight: 1.8 }}>
          Every flower we create is a labor of love. Using only the finest cotton and wool yarns, our artisans spend hours crafting each petal, each leaf, each stem — turning simple threads into timeless botanical art. Whether for a wedding bouquet, home decor, or a gift that lasts forever, our crochet flowers bring warmth and beauty into every space.
        </p>
        <a
          href="#contact"
          onClick={(e) => {
            e.preventDefault();
            document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
          }}
          className="inline-block mt-8 px-7 py-3 border border-terracotta text-terracotta hover:bg-terracotta hover:text-warm-brown rounded-xl font-sans text-sm transition-all duration-300"
        >
          Contact Us
        </a>
      </div>
    </section>
  );
}
