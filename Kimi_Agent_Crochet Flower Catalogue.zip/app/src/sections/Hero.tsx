import DriftingCrochetField from '@/components/DriftingCrochetField';
import { ChevronDown } from 'lucide-react';

export default function Hero() {
  const scrollToCatalogue = () => {
    document.getElementById('catalogue')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section
      id="hero"
      className="relative min-h-[100dvh] flex items-center justify-center overflow-hidden"
      style={{ backgroundColor: '#FDF6E9' }}
    >
      <DriftingCrochetField />

      <div className="relative z-10 text-center px-6 max-w-2xl mx-auto">
        <h1 className="font-display text-5xl md:text-[64px] text-warm-brown tracking-[2px] leading-tight">
          Petals
        </h1>
        <p className="font-sans text-lg md:text-xl text-taupe mt-3">
          Handcrafted Crochet Flowers
        </p>
        <p className="font-sans text-sm md:text-base text-sage mt-2 uppercase tracking-[3px]">
          Made with love in Pakistan
        </p>

        <button
          onClick={scrollToCatalogue}
          className="mt-8 px-8 py-3.5 bg-terracotta hover:bg-[#C49464] text-white font-sans text-base rounded-full transition-all duration-300 hover:scale-[1.02] shadow-lg"
        >
          Explore Catalogue
        </button>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-10">
        <button
          onClick={scrollToCatalogue}
          className="flex flex-col items-center gap-2 text-terracotta animate-pulse-soft"
          aria-label="Scroll down"
        >
          <ChevronDown className="w-5 h-5" />
          <div className="w-px h-10 bg-terracotta/40" />
        </button>
      </div>
    </section>
  );
}
